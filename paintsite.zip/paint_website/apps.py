from django.apps import AppConfig


class PaintWebsiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'paint_website'
